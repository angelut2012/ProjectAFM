clear
clc
R=50e-9 % tipradius
K=40% cantilever stiffness

Zmax=7000e-9% 6 um z piezo motion range
Zstd=0.11e-9%1.2e-9%
N=31% number of points

%sample property
%eg. teflon
Ysample=9e6% sample yield strength
Vsample=0.46
Esample=0.5516e9

%eg. Aluminium alloy 2014-T6	
% Ysample=400e6% sample yield strength
% Vsample=0.46
% Esample=0.5516e9


%% tip property
Etip=150e9% tip young's modulus
Ytip=7e9% tip yield strength
Vtip=0.27%0.26~0.28

clc
%% working condition, no yield change
Pcontact=min(Ysample,Ytip);% contact pressure
%% get Emax
Dsample_min=N*Zstd;
% Dtip=Zmax-Dsample;
% CR=sqrt(R*Dsample);
% A=pi*CR*CR;
A=pi*R*Dsample_min;
Fmax=Pcontact*A% max contact force
Dtip_max=Fmax/K
if (Dtip_max>Zmax-Dsample_min)
    disp('sample is too hard');
end
%%Emin
%% get Emin
Dtip_min=N*Zstd;
Fmin=Dtip_min*K;
A=Fmin/Pcontact;
Dsample_max=sqrt(A/R/pi)
if (Dsample_max>Zmax-Dtip_min)
    disp('sample is too hard');
end
%% get max min Young's modulus
F=[Fmax Fmin]
Dsample=[Dsample_min Dsample_max]
Ex=F./(4/3*R^0.5.*Dsample.^1.5)
Esample_range=(1-Vsample^2)./(1./Ex-(1-Vtip^2)/Etip)
ExGPa=Esample_range./1e9

