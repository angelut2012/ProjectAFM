#include  "TickTimer.h"
CTickTimer mCTickTimer_RealTime;
//CTickTimer mCTickTimer_NonRealTime;

//unsigned int mSystemTick = 0; 
//void SysTick_Handler(void)
//{
//	HAL_IncTick();
//	HAL_SYSTICK_IRQHandler();
//	mCTickTimer_RealTime.mSystemTick++;
////	if (mSystemTick == 0)
////		Timer_Handler();
//}
//