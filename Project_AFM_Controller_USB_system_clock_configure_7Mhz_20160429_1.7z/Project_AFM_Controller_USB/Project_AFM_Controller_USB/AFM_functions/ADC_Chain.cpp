#include "ADC_Chain.h"
CSEM mAFM_SEM;