#include "DAC.h"
CDAC mAFM_DAC;	