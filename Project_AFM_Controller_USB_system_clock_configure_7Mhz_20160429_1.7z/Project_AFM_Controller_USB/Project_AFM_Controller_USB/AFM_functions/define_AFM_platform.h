//#include "define_AFM_platform.h"
#ifndef __DEFINE_AFM_PLATFORM__
#define __DEFINE_AFM_PLATFORM__

#include "mbed.h"

typedef  unsigned char byte;
//#define byte uint8_t

// hardware port define
#define PORT_LED (PA_8)
#define PORT_TEMPERATURE (PC_1)



#endif // !__DEFINE_AFM_PLATFORM__
 
