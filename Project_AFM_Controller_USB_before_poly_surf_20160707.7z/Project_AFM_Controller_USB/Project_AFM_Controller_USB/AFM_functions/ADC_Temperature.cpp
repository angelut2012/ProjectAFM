#include "ADC_Temperature.h"
CTemperature mCTemperature;