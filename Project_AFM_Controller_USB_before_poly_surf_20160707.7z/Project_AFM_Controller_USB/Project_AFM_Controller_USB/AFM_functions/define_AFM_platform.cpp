#include "mbed.h"
#include "define_AFM_hardware.h"

#include "define_AFM_platform.h"


DigitalOut *p_LED = new DigitalOut(PORT_LED);
DigitalOut *p_Tdio1 = new DigitalOut(Tdio1);
DigitalOut *p_Tdio2 = new DigitalOut(Tdio2);
DigitalOut *p_Tdio3 = new DigitalOut(Tdio3);
DigitalOut *p_Tdio4 = new DigitalOut(Tdio4);
DigitalOut *p_Tdio5 = new DigitalOut(Tdio5);



