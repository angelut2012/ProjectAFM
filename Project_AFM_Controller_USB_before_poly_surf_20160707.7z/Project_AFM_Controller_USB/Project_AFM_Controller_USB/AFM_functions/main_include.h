//#include <math.h>
#include "define_AFM_hardware.h"
#include "TickTimer.h"
#include "USBSerial.h"

#include "PortNames.h"
#include "PinNames.h"
#include "DigitalOut.h"
#include "DigitalIn.h"


#include "main_AFM.h"
