#ifndef __MBED_INCLUDE__
#define __MBED_INCLUDE__

#include "TickTimer.h"
//extern void wait_us(float);
//extern void wait_ms(float);
//extern void wait(float);

#include "PortNames.h"
#include "PinNames.h"
#include "DigitalOut.h"
#include "DigitalIn.h"


#endif // !__MBED_INCLUDE__
