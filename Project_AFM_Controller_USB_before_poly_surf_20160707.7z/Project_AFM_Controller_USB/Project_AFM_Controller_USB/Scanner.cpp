#include "Scanner.h"


CScanner::CScanner(void)
{
}


CScanner::~CScanner(void)
{
}

//CScanner mCScannerX;
//CScanner mCScannerY;
//CScanner mCScannerZ;
CScanner mCScanner[3];